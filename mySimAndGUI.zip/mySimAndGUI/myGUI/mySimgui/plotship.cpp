#include "plotship.h"

PlotShip::PlotShip()
{

}
