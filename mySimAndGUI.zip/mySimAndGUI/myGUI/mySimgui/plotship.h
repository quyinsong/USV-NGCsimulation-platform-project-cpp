#ifndef PLOTSHIP_H
#define PLOTSHIP_H

#include <QPainter>
#include <QPaintEvent>
#include <QtMath>
#include <iostream>
#include <eigen3/Eigen/Dense>


class PlotShip
{
public:
    PlotShip();
};

#endif // PLOTSHIP_H
